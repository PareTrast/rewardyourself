from click import confirm
import flet as ft
from datetime import datetime
import data_manager  # Import the module we just created


# --- Helper Functions ---
def format_date(iso_string, include_time=False):
    """Formats an ISO date string for display."""
    if not iso_string:
        return ""
    try:
        dt = datetime.fromisoformat(iso_string)
        if include_time:
            return dt.strftime("%Y-%m-%d %H:%M")
        else:
            # Handle date-only strings (like YYYY-MM-DD from dueDate)
            if len(iso_string) == 10:
                return dt.strftime("%Y-%m-%d")  # Already in correct format essentially
            return dt.strftime("%Y-%m-%d")  # Default date format
    except (ValueError, TypeError):
        return iso_string  # Return original if parsing fails


# --- Main Application ---
def main(page: ft.Page):
    page.title = "Offline Task & Reward Tracker"
    page.vertical_alignment = ft.MainAxisAlignment.START
    page.horizontal_alignment = ft.CrossAxisAlignment.CENTER

    # --- Load Initial Data ---
    # Store the application's current data state in a dictionary
    app_data = data_manager.load_data()

    # --- UI Controls (Placeholders - Adapt to your layout) ---
    points_display = ft.Text(
        f"Points: {app_data.get('points', 0)}", size=20, weight=ft.FontWeight.BOLD
    )

    # Task Input Fields
    task_name_input = ft.TextField(label="Task Name", expand=True)
    task_points_input = ft.TextField(
        label="Points", keyboard_type=ft.KeyboardType.NUMBER, width=80
    )
    task_due_date_input = ft.TextField(
        label="Due Date (YYYY-MM-DD)", width=150
    )  # Consider ft.DatePicker later

    # Reward Input Fields
    reward_name_input = ft.TextField(label="Reward Name", expand=True)
    reward_cost_input = ft.TextField(
        label="Cost", keyboard_type=ft.KeyboardType.NUMBER, width=80
    )

    # Lists (use ListView for dynamic content)
    pending_tasks_list = ft.ListView(expand=True, spacing=5)
    completed_tasks_list = ft.ListView(expand=True, spacing=5)
    available_rewards_list = ft.ListView(expand=True, spacing=5)
    claimed_rewards_list = ft.ListView(expand=True, spacing=5)
    history_list = ft.ListView(expand=True, spacing=5)
    calendar_list = ft.ListView(expand=True, spacing=5)  # Simple list for calendar view

    # --- Dialogs ---
    confirm_delete_dialog = ft.AlertDialog(
        modal=True,
        title=ft.Text("Confirm Delete"),
        content=ft.Text("Are you sure you want to delete this item?"),
        actions=[
            ft.TextButton("Yes", on_click=lambda e: close_dialog("yes")),
            ft.TextButton("No", on_click=lambda e: close_dialog("no")),
        ],
        actions_alignment=ft.MainAxisAlignment.END,
    )
    page.dialog = confirm_delete_dialog  # Assign dialog to page

    info_dialog = ft.AlertDialog(
        title=ft.Text("Info"),
        content=ft.Text(""),  # Content set dynamically
        actions=[ft.TextButton("OK", on_click=lambda e: close_dialog())],
    )

    # --- File Pickers ---
    def on_export_result(e: ft.FilePickerResultEvent):
        if e.path:
            if data_manager.export_data_to_file(app_data, e.path):
                show_info_dialog("Data exported successfully!")
            else:
                show_info_dialog("Failed to export data.")
        else:
            print("Export cancelled.")

    def on_import_result(e: ft.FilePickerResultEvent):
        nonlocal app_data  # Allow modification of the outer scope variable
        if e.files and len(e.files) > 0:
            source_path = e.files[0].path
            imported_data = data_manager.import_data_from_file(source_path)
            if imported_data:
                if confirm(
                    "Importing will overwrite current data. Continue?"
                ):  # Basic confirmation
                    app_data = imported_data
                    # IMPORTANT: Save the newly imported data to the default location
                    data_manager.save_data(app_data)
                    refresh_all_ui()  # Update UI with imported data
                    show_info_dialog("Data imported successfully!")
                else:
                    print("Import cancelled by user.")
            else:
                show_info_dialog(
                    "Failed to import data. Check file format and version."
                )
        else:
            print("Import cancelled.")

    export_picker = ft.FilePicker(on_result=on_export_result)
    import_picker = ft.FilePicker(on_result=on_import_result)

    # Hide overlay controls initially
    page.overlay.extend([export_picker, import_picker])

    # --- UI Update Functions ---
    def update_points_display():
        points_display.value = f"Points: {app_data.get('points', 0)}"
        points_display.update()

    def create_task_ui(task):
        # Creates the UI controls for a single task item
        return ft.Container(  # Use Container for background/border if needed
            content=ft.Row(
                [
                    ft.Checkbox(
                        value=task.get("completed", False),
                        label=f"{task.get('name')} (+{task.get('points')} pts)",
                        data=task.get("id"),  # Store ID in data attribute
                        on_change=handle_task_complete_toggle,
                        disabled=task.get(
                            "completed", False
                        ),  # Disable checkbox if complete
                        expand=True,
                    ),
                    ft.Text(
                        (
                            f"Due: {format_date(task.get('dueDate'))}"
                            if task.get("dueDate")
                            else "No due date"
                        ),
                        size=10,
                        italic=True,
                    ),
                    ft.IconButton(
                        ft.icons.DELETE_OUTLINE,
                        tooltip="Delete Task",
                        on_click=handle_delete_item,
                        data=("task", task.get("id")),  # Store type and ID
                    ),
                ],
                alignment=ft.MainAxisAlignment.SPACE_BETWEEN,
            ),
            # Example styling:
            # bgcolor=ft.colors.GREEN_100 if task.get("completed") else ft.colors.BLUE_GREY_50,
            # border_radius=5,
            # padding=5
        )

    def update_task_lists():
        pending_tasks_list.controls.clear()
        completed_tasks_list.controls.clear()
        tasks = data_manager.get_tasks(app_data)
        for task in tasks:
            task_ui = create_task_ui(task)
            if task.get("completed"):
                completed_tasks_list.controls.append(task_ui)
            else:
                pending_tasks_list.controls.append(task_ui)
        pending_tasks_list.update()
        completed_tasks_list.update()

    def create_reward_ui(reward):
        # Creates the UI controls for a single reward item
        can_afford = app_data.get("points", 0) >= reward.get("cost", 0)
        return ft.Container(
            content=ft.Row(
                [
                    ft.Text(
                        f"{reward.get('name')} ({reward.get('cost')} pts)", expand=True
                    ),
                    ft.ElevatedButton(
                        "Claim",
                        icon=ft.icons.STAR_BORDER,
                        on_click=handle_claim_reward,
                        data=reward.get("id"),  # Store ID
                        disabled=reward.get("claimed")
                        or not can_afford,  # Disable if claimed or cannot afford
                        tooltip=(
                            "Claim this reward"
                            if not reward.get("claimed")
                            else "Already claimed"
                        ),
                    ),
                    ft.IconButton(
                        ft.icons.DELETE_OUTLINE,
                        tooltip="Delete Reward",
                        on_click=handle_delete_item,
                        data=("reward", reward.get("id")),  # Store type and ID
                    ),
                ],
                alignment=ft.MainAxisAlignment.SPACE_BETWEEN,
            ),
            # Example styling:
            # bgcolor=ft.colors.AMBER_100 if reward.get("claimed") else ft.colors.BLUE_GREY_50,
            # border_radius=5,
            # padding=5
        )

    def update_reward_lists():
        available_rewards_list.controls.clear()
        claimed_rewards_list.controls.clear()
        rewards = data_manager.get_rewards(app_data)
        for reward in rewards:
            reward_ui = create_reward_ui(reward)
            if reward.get("claimed"):
                claimed_rewards_list.controls.append(reward_ui)
            else:
                available_rewards_list.controls.append(reward_ui)
        available_rewards_list.update()
        claimed_rewards_list.update()

    def update_history_list():
        history_list.controls.clear()
        history_items = data_manager.get_history(app_data)
        for item in history_items:
            history_list.controls.append(
                ft.Text(f"{format_date(item['timestamp'], True)}: {item['text']}")
            )
        history_list.update()

    def update_calendar_list():
        calendar_list.controls.clear()
        calendar_tasks = data_manager.get_tasks_for_calendar(app_data)
        last_date = None
        for task in calendar_tasks:
            due_date_str = format_date(task.get("dueDate"))
            if due_date_str != last_date:
                calendar_list.controls.append(
                    ft.Text(due_date_str, weight=ft.FontWeight.BOLD, size=14)
                )
                last_date = due_date_str
            calendar_list.controls.append(
                ft.Text(
                    f"  - {task.get('name')} {'(Completed)' if task.get('completed') else ''}"
                )
            )
        calendar_list.update()

    def refresh_all_ui():
        """Calls all UI update functions."""
        update_points_display()
        update_task_lists()
        update_reward_lists()
        update_history_list()
        update_calendar_list()
        # page.update() # Often needed after multiple control updates

    # --- Event Handlers ---
    def handle_add_task(e):
        name = task_name_input.value.strip()
        points_str = task_points_input.value.strip()
        due_date_str = task_due_date_input.value.strip()  # Expects YYYY-MM-DD

        if not name or not points_str:
            show_info_dialog("Task Name and Points are required.")
            return
        try:
            points = int(points_str)
            if points < 0:
                raise ValueError("Points cannot be negative")
        except ValueError:
            show_info_dialog(
                "Invalid points value. Please enter a non-negative number."
            )
            return

        # Basic date validation (can be improved)
        due_date = None
        if due_date_str:
            try:
                datetime.strptime(due_date_str, "%Y-%m-%d")
                due_date = due_date_str
            except ValueError:
                show_info_dialog("Invalid Due Date format. Please use YYYY-MM-DD.")
                return

        task_details = {
            "name": name,
            "points": points,
            "dueDate": due_date,
            "description": "",  # Add description field if needed
        }
        data_manager.add_task(app_data, task_details)

        # Clear inputs
        task_name_input.value = ""
        task_points_input.value = ""
        task_due_date_input.value = ""

        refresh_all_ui()
        page.update()  # Update page after adding

    def handle_add_reward(e):
        name = reward_name_input.value.strip()
        cost_str = reward_cost_input.value.strip()

        if not name or not cost_str:
            show_info_dialog("Reward Name and Cost are required.")
            return
        try:
            cost = int(cost_str)
            if cost < 0:
                raise ValueError("Cost cannot be negative")
        except ValueError:
            show_info_dialog("Invalid cost value. Please enter a non-negative number.")
            return

        reward_details = {
            "name": name,
            "cost": cost,
            "description": "",  # Add description field if needed
        }
        data_manager.add_reward(app_data, reward_details)

        # Clear inputs
        reward_name_input.value = ""
        reward_cost_input.value = ""

        refresh_all_ui()
        page.update()

    def handle_task_complete_toggle(e: ft.ControlEvent):
        task_id = e.control.data  # Get task ID from checkbox data
        is_checked = e.control.value  # Checkbox is now checked (meaning complete)

        if is_checked and task_id:
            data_manager.complete_task(app_data, task_id)
            refresh_all_ui()
            page.update()
        # No action needed if unchecking (shouldn't be possible if disabled when complete)

    def handle_claim_reward(e: ft.ControlEvent):
        reward_id = e.control.data  # Get reward ID from button data
        if reward_id:
            success = data_manager.claim_reward(app_data, reward_id)
            if success:
                refresh_all_ui()
                page.update()
            else:
                # Check why it failed (already claimed or not enough points)
                reward_index = data_manager.find_reward_index(app_data, reward_id)
                if reward_index != -1:
                    reward = app_data["rewards"][reward_index]
                    if not reward.get("claimed"):  # Must be due to points
                        show_info_dialog("Not enough points to claim this reward.")
                # No message needed if already claimed, as button should be disabled

    # --- Deletion Handling with Confirmation ---
    item_to_delete = {"type": None, "id": None}  # Store item info for dialog callback

    def handle_delete_item(e: ft.ControlEvent):
        nonlocal item_to_delete
        item_type, item_id = (
            e.control.data
        )  # ("task", "some-uuid") or ("reward", "other-uuid")
        item_to_delete["type"] = item_type
        item_to_delete["id"] = item_id
        confirm_delete_dialog.open = True
        page.update()

    def close_dialog(result=None):
        nonlocal item_to_delete
        confirm_delete_dialog.open = False
        info_dialog.open = False  # Close info dialog too

        if result == "yes" and item_to_delete["id"]:
            deleted = False
            if item_to_delete["type"] == "task":
                deleted = data_manager.delete_task(app_data, item_to_delete["id"])
            elif item_to_delete["type"] == "reward":
                deleted = data_manager.delete_reward(app_data, item_to_delete["id"])

            if deleted:
                refresh_all_ui()
            else:
                print(
                    f"Failed to delete {item_to_delete['type']} with ID {item_to_delete['id']}"
                )

        # Reset item_to_delete after handling
        item_to_delete = {"type": None, "id": None}
        page.update()

    def show_info_dialog(message):
        info_dialog.content = ft.Text(message)
        info_dialog.open = True
        page.update()

    # --- Export/Import Button Handlers ---
    def trigger_export(e):
        export_picker.save_file(
            dialog_title="Export Data As...",
            file_name=f"task_reward_data_{datetime.now().strftime('%Y%m%d')}.json",
            allowed_extensions=["json"],
        )

    def trigger_import(e):
        import_picker.pick_files(
            dialog_title="Import Data File",
            allow_multiple=False,
            allowed_extensions=["json"],
        )

    # --- Build the UI Layout ---
    ft.SafeArea(
        page.add(
            ft.Column(
                [
                    points_display,
                    ft.Divider(),
                    # --- Tasks Section ---
                    ft.Text("Add Task", size=16, weight=ft.FontWeight.BOLD),
                    ft.Row([task_name_input, task_points_input, task_due_date_input]),
                    ft.ElevatedButton(
                        "Add Task", icon=ft.icons.ADD, on_click=handle_add_task
                    ),
                    ft.Text("Pending Tasks", size=16, weight=ft.FontWeight.BOLD),
                    ft.Container(
                        content=pending_tasks_list,
                        height=200,
                        border=ft.border.all(1, ft.colors.OUTLINE),
                    ),  # Constrain height
                    ft.Text("Completed Tasks", size=16, weight=ft.FontWeight.BOLD),
                    ft.Container(
                        content=completed_tasks_list,
                        height=150,
                        border=ft.border.all(1, ft.colors.OUTLINE),
                    ),
                    ft.Divider(),
                    # --- Rewards Section ---
                    ft.Text("Add Reward", size=16, weight=ft.FontWeight.BOLD),
                    ft.Row([reward_name_input, reward_cost_input]),
                    ft.ElevatedButton(
                        "Add Reward",
                        icon=ft.icons.ADD_SHOPPING_CART,
                        on_click=handle_add_reward,
                    ),
                    ft.Text("Available Rewards", size=16, weight=ft.FontWeight.BOLD),
                    ft.Container(
                        content=available_rewards_list,
                        height=150,
                        border=ft.border.all(1, ft.colors.OUTLINE),
                    ),
                    ft.Text("Claimed Rewards", size=16, weight=ft.FontWeight.BOLD),
                    ft.Container(
                        content=claimed_rewards_list,
                        height=100,
                        border=ft.border.all(1, ft.colors.OUTLINE),
                    ),
                    ft.Divider(),
                    # --- Views ---
                    ft.Row(  # Use Row to place views side-by-side if desired
                        [
                            ft.Column(
                                [
                                    ft.Text(
                                        "Calendar (Tasks by Due Date)",
                                        size=16,
                                        weight=ft.FontWeight.BOLD,
                                    ),
                                    ft.Container(
                                        content=calendar_list,
                                        height=200,
                                        border=ft.border.all(1, ft.colors.OUTLINE),
                                    ),
                                ],
                                expand=True,
                            ),  # Make columns expand
                            ft.Column(
                                [
                                    ft.Text(
                                        "History", size=16, weight=ft.FontWeight.BOLD
                                    ),
                                    ft.Container(
                                        content=history_list,
                                        height=200,
                                        border=ft.border.all(1, ft.colors.OUTLINE),
                                    ),
                                ],
                                expand=True,
                            ),
                        ]
                    ),
                    ft.Divider(),
                    # --- Data Management ---
                    ft.Text("Manage Data", size=16, weight=ft.FontWeight.BOLD),
                    ft.Row(
                        [
                            ft.ElevatedButton(
                                "Export Data",
                                icon=ft.icons.UPLOAD_FILE,
                                on_click=trigger_export,
                            ),
                            ft.ElevatedButton(
                                "Import Data",
                                icon=ft.icons.DOWNLOAD,
                                on_click=trigger_import,
                            ),
                        ]
                    ),
                    ft.Text(
                        "Warning: Importing data will overwrite current local data.",
                        size=10,
                        italic=True,
                        color=ft.colors.ERROR,
                    ),
                ],
                scroll=ft.ScrollMode.ADAPTIVE,  # Make the main column scrollable if content overflows
                expand=True,  # Allow column to take available space
            )
        )
    )

    # --- Initial UI Population ---
    refresh_all_ui()
    page.update()  # Initial page render


# --- Run the App ---
if __name__ == "__main__":
    # Install appdirs if you don't have it: pip install appdirs
    ft.app(target=main)
