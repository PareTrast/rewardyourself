# data_manager.py
import json
import os
import uuid
from datetime import datetime
import appdirs  # Helper library to find appropriate user data directories

DATA_FILENAME = "app_data.json"
DATA_VERSION = 1


# --- Helper to get a reliable data storage path ---
def get_data_path():
    """Gets the path to the data file in a user-specific directory."""
    app_name = "MyOfflineTaskApp"  # Choose a name for your app
    author = "MyAppAuthor"  # Choose an author name
    data_dir = appdirs.user_data_dir(app_name, author)
    if not os.path.exists(data_dir):
        os.makedirs(data_dir)
        print(f"Created data directory: {data_dir}")
    return os.path.join(data_dir, DATA_FILENAME)


# --- Core Load/Save ---
def load_data():
    """Loads data from the JSON file."""
    path = get_data_path()
    default_data = {"version": DATA_VERSION, "tasks": [], "rewards": [], "points": 0}
    if not os.path.exists(path):
        print(f"Data file not found at {path}. Starting fresh.")
        return default_data
    try:
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
            # Basic validation (add more checks as needed)
            if (
                not isinstance(data, dict)
                or data.get("version") != DATA_VERSION
                or not isinstance(data.get("tasks"), list)
                or not isinstance(data.get("rewards"), list)
                or not isinstance(data.get("points"), int)
            ):
                print(
                    f"Data file at {path} is invalid or incompatible. Starting fresh."
                )
                # Optionally backup the invalid file here
                return default_data
            print(f"Data loaded successfully from {path}")
            return data
    except (json.JSONDecodeError, IOError) as e:
        print(f"Error loading data file from {path}: {e}. Starting fresh.")
        # Optionally backup the corrupted file here
        return default_data


def save_data(data):
    """Saves the current data state to the JSON file."""
    path = get_data_path()
    try:
        # Ensure version is up-to-date before saving
        data["version"] = DATA_VERSION
        with open(path, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2)  # Use indent for readability
        # print(f"Data saved successfully to {path}") # Can be noisy
    except IOError as e:
        print(f"Error saving data to {path}: {e}")
        # Consider notifying the user in the UI if saving fails critically


# --- Point Management ---
def update_user_points(data, amount):
    """Updates user points within the data dictionary and saves."""
    current_points = data.get("points", 0)
    new_points = max(0, current_points + amount)  # Prevent negative points
    data["points"] = new_points
    save_data(data)
    return new_points


# --- Task Management ---
def get_tasks(data):
    return data.get("tasks", [])


def add_task(data, task_details):
    """Adds a new task to the data and saves."""
    tasks = data.get("tasks", [])
    new_task = {
        "id": str(uuid.uuid4()),
        "name": task_details.get("name", "Unnamed Task"),
        "description": task_details.get("description", ""),
        "points": int(task_details.get("points", 0)),
        "dueDate": task_details.get(
            "dueDate"
        ),  # Store as ISO string (YYYY-MM-DD) or None
        "completed": False,
        "createdAt": datetime.now().isoformat(),
        "updatedAt": datetime.now().isoformat(),
        "completedAt": None,
    }
    tasks.append(new_task)
    data["tasks"] = tasks
    save_data(data)
    return new_task


def find_task_index(data, task_id):
    """Finds the index of a task by ID."""
    tasks = data.get("tasks", [])
    for i, task in enumerate(tasks):
        if task.get("id") == task_id:
            return i
    return -1


def update_task(data, task_id, updates):
    """Updates a specific task and saves."""
    task_index = find_task_index(data, task_id)
    if task_index != -1:
        data["tasks"][task_index].update(updates)
        data["tasks"][task_index]["updatedAt"] = datetime.now().isoformat()
        save_data(data)
        return data["tasks"][task_index]
    return None


def complete_task(data, task_id):
    """Marks a task as complete, updates points, and saves."""
    task_index = find_task_index(data, task_id)
    if task_index != -1:
        task = data["tasks"][task_index]
        if not task.get("completed"):
            updated_task = update_task(
                data,
                task_id,
                {
                    "completed": True,
                    "completedAt": datetime.now().isoformat(),
                },
            )
            if updated_task:
                update_user_points(data, task.get("points", 0))  # Add points
            return updated_task
        return task  # Already completed
    return None


def delete_task(data, task_id):
    """Deletes a task and saves."""
    initial_length = len(data.get("tasks", []))
    # Optional: Refund points if deleting a completed task? Decide your logic.
    # task_index = find_task_index(data, task_id)
    # if task_index != -1 and data["tasks"][task_index].get("completed"):
    #     update_user_points(data, -data["tasks"][task_index].get("points", 0))

    data["tasks"] = [
        task for task in data.get("tasks", []) if task.get("id") != task_id
    ]
    if len(data["tasks"]) < initial_length:
        save_data(data)
        return True
    return False


# --- Reward Management --- (Similar structure to tasks)
def get_rewards(data):
    return data.get("rewards", [])


def add_reward(data, reward_details):
    """Adds a new reward and saves."""
    rewards = data.get("rewards", [])
    new_reward = {
        "id": str(uuid.uuid4()),
        "name": reward_details.get("name", "Unnamed Reward"),
        "cost": int(reward_details.get("cost", 0)),
        "description": reward_details.get("description", ""),
        "claimed": False,
        "createdAt": datetime.now().isoformat(),
        "updatedAt": datetime.now().isoformat(),
        "claimedAt": None,
    }
    rewards.append(new_reward)
    data["rewards"] = rewards
    save_data(data)
    return new_reward


def find_reward_index(data, reward_id):
    """Finds the index of a reward by ID."""
    rewards = data.get("rewards", [])
    for i, reward in enumerate(rewards):
        if reward.get("id") == reward_id:
            return i
    return -1


def update_reward(data, reward_id, updates):
    """Updates a specific reward and saves."""
    reward_index = find_reward_index(data, reward_id)
    if reward_index != -1:
        data["rewards"][reward_index].update(updates)
        data["rewards"][reward_index]["updatedAt"] = datetime.now().isoformat()
        save_data(data)
        return data["rewards"][reward_index]
    return None


def claim_reward(data, reward_id):
    """Marks a reward as claimed, deducts points, and saves. Returns True on success, False otherwise."""
    reward_index = find_reward_index(data, reward_id)
    if reward_index != -1:
        reward = data["rewards"][reward_index]
        current_points = data.get("points", 0)
        if not reward.get("claimed") and current_points >= reward.get("cost", 0):
            updated_reward = update_reward(
                data,
                reward_id,
                {
                    "claimed": True,
                    "claimedAt": datetime.now().isoformat(),
                },
            )
            if updated_reward:
                update_user_points(data, -reward.get("cost", 0))  # Deduct points
                return True  # Claim successful
        elif reward.get("claimed"):
            print("Reward already claimed.")
            return False  # Indicate failure (already claimed)
        else:  # Not enough points
            print("Not enough points to claim reward.")
            return False  # Indicate failure (cost)
    return False  # Reward not found


def delete_reward(data, reward_id):
    """Deletes a reward and saves."""
    initial_length = len(data.get("rewards", []))
    # Optional: Refund points if deleting a claimed reward?
    # reward_index = find_reward_index(data, reward_id)
    # if reward_index != -1 and data["rewards"][reward_index].get("claimed"):
    #     update_user_points(data, data["rewards"][reward_index].get("cost", 0))

    data["rewards"] = [
        reward for reward in data.get("rewards", []) if reward.get("id") != reward_id
    ]
    if len(data["rewards"]) < initial_length:
        save_data(data)
        return True
    return False


# --- History / Calendar Data Generation ---
def get_history(data):
    """Generates a sorted history log from tasks and rewards."""
    history = []
    for task in data.get("tasks", []):
        if task.get("completed") and task.get("completedAt"):
            history.append(
                {
                    "type": "task_completed",
                    "timestamp": task["completedAt"],
                    "text": f"Completed Task: {task.get('name', '')} (+{task.get('points', 0)} pts)",
                    "data": task,  # Include original data if needed later
                }
            )
    for reward in data.get("rewards", []):
        if reward.get("claimed") and reward.get("claimedAt"):
            history.append(
                {
                    "type": "reward_claimed",
                    "timestamp": reward["claimedAt"],
                    "text": f"Claimed Reward: {reward.get('name', '')} (-{reward.get('cost', 0)} pts)",
                    "data": reward,
                }
            )
    # Sort by timestamp (string comparison works for ISO format), newest first
    history.sort(key=lambda x: x["timestamp"], reverse=True)
    return history


def get_tasks_for_calendar(data):
    """Gets tasks with due dates, sorted by due date."""
    tasks_with_due_dates = [
        task for task in data.get("tasks", []) if task.get("dueDate")
    ]
    # Sort by due date (string comparison works for YYYY-MM-DD)
    tasks_with_due_dates.sort(key=lambda x: x["dueDate"])
    return tasks_with_due_dates


# --- Data Export/Import ---
def export_data_to_file(data, target_path):
    """Saves the current data state to a specific file path."""
    try:
        data["version"] = DATA_VERSION  # Ensure version is included
        with open(target_path, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2)
        print(f"Data exported successfully to {target_path}")
        return True
    except (IOError, TypeError) as e:
        print(f"Error exporting data to {target_path}: {e}")
        return False


def import_data_from_file(source_path):
    """Loads data from a specific file path, validates it, and returns it."""
    try:
        with open(source_path, "r", encoding="utf-8") as f:
            imported_data = json.load(f)

        # --- Validation ---
        if not isinstance(imported_data, dict):
            raise ValueError("Invalid file content: Not a JSON object.")
        if imported_data.get("version") != DATA_VERSION:
            raise ValueError(
                f"Incompatible data version. Expected {DATA_VERSION}, got {imported_data.get('version', 'unknown')}."
            )
        if (
            not isinstance(imported_data.get("tasks"), list)
            or not isinstance(imported_data.get("rewards"), list)
            or not isinstance(imported_data.get("points"), int)
        ):
            raise ValueError(
                "Data file is missing required fields (tasks, rewards, points) or they have incorrect types."
            )
        # Add more specific validation for task/reward structure if needed

        print(f"Data imported successfully from {source_path}")
        return imported_data  # Return the validated data

    except (IOError, json.JSONDecodeError, ValueError) as e:
        print(f"Error importing data from {source_path}: {e}")
        return None  # Indicate failure
