import flet as ft
from datetime import datetime
import data_manager  # Import the module we just created
import traceback  # Added for potential error logging during import


# --- Helper Functions ---
def format_date(iso_string, include_time=False):
    """Formats an ISO date string for display."""
    if not iso_string:
        return ""
    try:
        dt = datetime.fromisoformat(iso_string)
        if include_time:
            return dt.strftime("%Y-%m-%d %H:%M")
        else:
            # Handle date-only strings (like YYYY-MM-DD from dueDate)
            if len(iso_string) == 10:
                # For YYYY-MM-DD, strftime might not be needed if format is already correct
                # but using it ensures consistency if input varies slightly
                return dt.strftime("%Y-%m-%d")
            return dt.strftime("%Y-%m-%d")  # Default date format
    except (ValueError, TypeError):
        # Log the error for debugging?
        # print(f"Error formatting date: {iso_string} - {e}")
        return iso_string  # Return original if parsing fails


# --- Main Application ---
def main(page: ft.Page):
    page.title = "Offline Task & Reward Tracker"
    page.vertical_alignment = ft.MainAxisAlignment.START
    page.horizontal_alignment = ft.CrossAxisAlignment.CENTER

    # --- Load Initial Data ---
    # Store the application's current data state in a dictionary
    try:
        app_data = data_manager.load_data()
    except Exception as e:
        # Handle critical load error - show message and stop
        print(f"CRITICAL ERROR loading data: {e}\n{traceback.format_exc()}")
        page.add(
            ft.Text(f"Fatal Error: Could not load data.\n{e}", color=ft.Colors.RED)
        )
        page.update()
        return  # Stop execution

    # --- UI Controls ---
    points_display = ft.Text(
        f"Points: {app_data.get('points', 0)}", size=20, weight=ft.FontWeight.BOLD
    )

    # Task Input Fields
    task_name_input = ft.TextField(label="Task Name", expand=True)
    task_points_input = ft.TextField(
        label="Points",
        keyboard_type=ft.KeyboardType.NUMBER,
        width=80,
        input_filter=ft.InputFilter(allow=True, regex_string=r"[0-9]"),
    )
    task_due_date_input = ft.TextField(
        label="Due Date (YYYY-MM-DD)", width=150, hint_text="YYYY-MM-DD"
    )  # Consider ft.DatePicker later

    # Reward Input Fields
    reward_name_input = ft.TextField(label="Reward Name", expand=True)
    reward_cost_input = ft.TextField(
        label="Cost",
        keyboard_type=ft.KeyboardType.NUMBER,
        width=80,
        input_filter=ft.InputFilter(allow=True, regex_string=r"[0-9]"),
    )

    # Lists (use ListView for dynamic content)
    pending_tasks_list = ft.ListView(expand=True, spacing=5, auto_scroll=True)
    completed_tasks_list = ft.ListView(expand=True, spacing=5, auto_scroll=True)
    available_rewards_list = ft.ListView(expand=True, spacing=5, auto_scroll=True)
    claimed_rewards_list = ft.ListView(expand=True, spacing=5, auto_scroll=True)
    history_list = ft.ListView(expand=True, spacing=5, auto_scroll=True)
    calendar_list = ft.ListView(
        expand=True, spacing=5, auto_scroll=True
    )  # Simple list for calendar view

    # --- Dialogs ---
    confirm_delete_dialog = ft.AlertDialog(
        modal=True,
        title=ft.Text("Confirm Delete"),
        content=ft.Text("Are you sure you want to delete this item?"),
        actions=[
            ft.TextButton("Yes", on_click=lambda e: close_dialog("yes")),
            ft.TextButton("No", on_click=lambda e: close_dialog("no")),
        ],
        actions_alignment=ft.MainAxisAlignment.END,
    )

    info_dialog = ft.AlertDialog(
        title=ft.Text("Info"),
        content=ft.Text(""),  # Content set dynamically
        actions=[ft.TextButton("OK", on_click=lambda e: close_dialog())],
    )

    confirm_import_dialog = ft.AlertDialog(
        modal=True,
        title=ft.Text("Confirm Import"),
        content=ft.Text(
            "Importing will overwrite all current data. Are you sure you want to continue?"
        ),
        actions=[
            ft.TextButton(
                "Yes, Overwrite", on_click=lambda e: close_dialog("import_yes")
            ),
            ft.TextButton("Cancel", on_click=lambda e: close_dialog("import_no")),
        ],
        actions_alignment=ft.MainAxisAlignment.END,
    )

    # Assign dialogs to page - only one can be active at a time easily this way
    # We'll manage opening them manually
    # page.dialog = confirm_delete_dialog

    # --- File Pickers ---
    def on_export_result(e: ft.FilePickerResultEvent):
        if e.path:
            # Ensure the path ends with .json if user didn't type it
            export_path = e.path
            if not export_path.lower().endswith(".json"):
                export_path += ".json"

            if data_manager.export_data_to_file(app_data, export_path):
                show_info_dialog("Data exported successfully!")
            else:
                show_info_dialog("Failed to export data.")
        else:
            print("Export cancelled.")
            # show_info_dialog("Export cancelled.") # Optional feedback

    # Store import details temporarily for confirmation dialog
    pending_import_data = {"data": None, "path": None}

    def on_import_result(e: ft.FilePickerResultEvent):
        nonlocal app_data, pending_import_data
        if e.files and len(e.files) > 0:
            source_path = e.files[0].path
            imported_data = data_manager.import_data_from_file(source_path)
            if imported_data:
                # Store data and path, then show confirmation dialog
                pending_import_data["data"] = imported_data
                pending_import_data["path"] = source_path
                page.dialog = confirm_import_dialog  # Set the active dialog
                confirm_import_dialog.open = True
                page.update()
            else:
                show_info_dialog(
                    "Failed to import data. Check file format, version, and permissions."
                )
        else:
            print("Import cancelled.")
            # show_info_dialog("Import cancelled.") # Optional feedback

    export_picker = ft.FilePicker(on_result=on_export_result)
    import_picker = ft.FilePicker(on_result=on_import_result)

    # Hide overlay controls initially
    page.overlay.extend([export_picker, import_picker])

    # --- UI Update Functions ---
    def update_points_display():
        points_display.value = f"Points: {app_data.get('points', 0)}"
        # No need to call update() on individual elements if refresh_all_ui calls page.update()
        # points_display.update()

    def create_task_ui(task):
        # Creates the UI controls for a single task item
        return ft.Container(  # Use Container for background/border/padding
            content=ft.Row(
                [
                    ft.Checkbox(
                        value=task.get("completed", False),
                        label=f"{task.get('name')} (+{task.get('points')} pts)",
                        data=task.get("id"),  # Store ID in data attribute
                        on_change=handle_task_complete_toggle,
                        disabled=task.get(
                            "completed", False
                        ),  # Disable checkbox if complete
                        expand=True,
                    ),
                    ft.Text(
                        (
                            f"Due: {format_date(task.get('dueDate'))}"
                            if task.get("dueDate")
                            else "No due date"
                        ),
                        size=10,
                        italic=True,
                        width=90,  # Give date some space
                        text_align=ft.TextAlign.RIGHT,
                    ),
                    ft.IconButton(
                        ft.Icons.DELETE_OUTLINE,
                        tooltip="Delete Task",
                        on_click=handle_delete_item,
                        data=("task", task.get("id")),  # Store type and ID
                    ),
                ],
                alignment=ft.MainAxisAlignment.SPACE_BETWEEN,
                vertical_alignment=ft.CrossAxisAlignment.CENTER,
            ),
            # Example styling: Add padding for better spacing
            padding=ft.padding.symmetric(vertical=2, horizontal=5),
            border=ft.border.only(
                bottom=ft.border.BorderSide(1, ft.Colors.BLACK12)
            ),  # Subtle separator
        )

    def update_task_lists():
        pending_tasks_list.controls.clear()
        completed_tasks_list.controls.clear()
        tasks = sorted(
            data_manager.get_tasks(app_data), key=lambda t: t.get("createdAt", "")
        )  # Sort by creation time
        for task in tasks:
            task_ui = create_task_ui(task)
            if task.get("completed"):
                completed_tasks_list.controls.append(task_ui)
            else:
                pending_tasks_list.controls.append(task_ui)
        # No need for individual updates if page.update() is called later
        # pending_tasks_list.update()
        # completed_tasks_list.update()

    def create_reward_ui(reward):
        # Creates the UI controls for a single reward item
        can_afford = app_data.get("points", 0) >= reward.get("cost", 0)
        is_claimed = reward.get("claimed", False)

        return ft.Container(
            content=ft.Row(
                [
                    ft.Text(
                        f"{reward.get('name')} ({reward.get('cost')} pts)", expand=True
                    ),
                    ft.ElevatedButton(
                        "Claim" if not is_claimed else "Claimed",
                        icon=ft.Icons.STAR if is_claimed else ft.Icons.STAR_BORDER,
                        on_click=handle_claim_reward,
                        data=reward.get("id"),  # Store ID
                        disabled=is_claimed
                        or not can_afford,  # Disable if claimed or cannot afford
                        tooltip=(
                            "Claim this reward"
                            if not is_claimed and can_afford
                            else (
                                "Already claimed" if is_claimed else "Not enough points"
                            )
                        ),
                    ),
                    ft.IconButton(
                        ft.Icons.DELETE_OUTLINE,
                        tooltip="Delete Reward",
                        on_click=handle_delete_item,
                        data=("reward", reward.get("id")),  # Store type and ID
                    ),
                ],
                alignment=ft.MainAxisAlignment.SPACE_BETWEEN,
                vertical_alignment=ft.CrossAxisAlignment.CENTER,
            ),
            padding=ft.padding.symmetric(vertical=2, horizontal=5),
            border=ft.border.only(bottom=ft.border.BorderSide(1, ft.Colors.BLACK12)),
        )

    def update_reward_lists():
        available_rewards_list.controls.clear()
        claimed_rewards_list.controls.clear()
        rewards = sorted(
            data_manager.get_rewards(app_data), key=lambda r: r.get("createdAt", "")
        )
        for reward in rewards:
            reward_ui = create_reward_ui(reward)
            if reward.get("claimed"):
                claimed_rewards_list.controls.append(reward_ui)
            else:
                available_rewards_list.controls.append(reward_ui)
        # available_rewards_list.update()
        # claimed_rewards_list.update()

    def update_history_list():
        history_list.controls.clear()
        history_items = data_manager.get_history(
            app_data
        )  # Already sorted by data_manager
        if not history_items:
            history_list.controls.append(
                ft.Text("No history yet.", italic=True, color=ft.Colors.BLACK54)
            )
        else:
            for item in history_items:
                history_list.controls.append(
                    ft.Text(
                        f"{format_date(item['timestamp'], True)}: {item['text']}",
                        size=12,
                    )
                )
        # history_list.update()

    def update_calendar_list():
        calendar_list.controls.clear()
        calendar_tasks = data_manager.get_tasks_for_calendar(
            app_data
        )  # Already sorted by data_manager
        if not calendar_tasks:
            calendar_list.controls.append(
                ft.Text(
                    "No tasks with due dates.", italic=True, color=ft.Colors.BLACK54
                )
            )
        else:
            last_date = None
            for task in calendar_tasks:
                due_date_str = format_date(task.get("dueDate"))
                if due_date_str != last_date:
                    calendar_list.controls.append(
                        ft.Text(due_date_str, weight=ft.FontWeight.BOLD, size=14)
                    )
                    last_date = due_date_str

                status = "(Completed)" if task.get("completed") else ""
                # Check if overdue and not completed
                is_overdue = False
                if not task.get("completed") and task.get("dueDate"):
                    try:
                        due_dt = datetime.strptime(
                            task.get("dueDate"), "%Y-%m-%d"
                        ).date()
                        if due_dt < datetime.now().date():
                            is_overdue = True
                            status = "(OVERDUE)"
                    except ValueError:
                        pass  # Ignore formatting errors for overdue check

                calendar_list.controls.append(
                    ft.Text(
                        f"  - {task.get('name')} {status}",
                        color=ft.Colors.RED if is_overdue else None,
                        size=12,
                    )
                )
        # calendar_list.update()

    def refresh_all_ui():
        """Calls all UI update functions and updates the page."""
        update_points_display()
        update_task_lists()
        update_reward_lists()
        update_history_list()
        update_calendar_list()
        page.update()  # Update the page once after all controls are updated

    # --- Event Handlers ---
    def handle_add_task(e):
        name = task_name_input.value.strip()
        points_str = task_points_input.value.strip()
        due_date_str = task_due_date_input.value.strip()  # Expects YYYY-MM-DD

        if not name or not points_str:
            show_info_dialog("Task Name and Points are required.")
            return
        try:
            points = int(points_str)
            if points < 0:
                raise ValueError("Points cannot be negative")
        except ValueError:
            show_info_dialog(
                "Invalid points value. Please enter a non-negative number."
            )
            return

        # Basic date validation (can be improved)
        due_date = None
        if due_date_str:
            try:
                # Validate format strictly
                datetime.strptime(due_date_str, "%Y-%m-%d")
                due_date = due_date_str
            except ValueError:
                show_info_dialog("Invalid Due Date format. Please use YYYY-MM-DD.")
                return

        task_details = {
            "name": name,
            "points": points,
            "dueDate": due_date,
            "description": "",  # Add description field if needed
        }
        data_manager.add_task(app_data, task_details)

        # Clear inputs
        task_name_input.value = ""
        task_points_input.value = ""
        task_due_date_input.value = ""
        task_name_input.focus()  # Set focus back to name input

        refresh_all_ui()
        # page.update() # Called by refresh_all_ui

    def handle_add_reward(e):
        name = reward_name_input.value.strip()
        cost_str = reward_cost_input.value.strip()

        if not name or not cost_str:
            show_info_dialog("Reward Name and Cost are required.")
            return
        try:
            cost = int(cost_str)
            if cost < 0:
                raise ValueError("Cost cannot be negative")
        except ValueError:
            show_info_dialog("Invalid cost value. Please enter a non-negative number.")
            return

        reward_details = {
            "name": name,
            "cost": cost,
            "description": "",  # Add description field if needed
        }
        data_manager.add_reward(app_data, reward_details)

        # Clear inputs
        reward_name_input.value = ""
        reward_cost_input.value = ""
        reward_name_input.focus()

        refresh_all_ui()
        # page.update() # Called by refresh_all_ui

    def handle_task_complete_toggle(e: ft.ControlEvent):
        task_id = e.control.data  # Get task ID from checkbox data
        is_checked = e.control.value  # Checkbox is now checked (meaning complete)

        if is_checked and task_id:
            completed_task = data_manager.complete_task(app_data, task_id)
            if completed_task:
                refresh_all_ui()
                # page.update() # Called by refresh_all_ui
            else:
                # Task might already be complete or not found, refresh anyway to be safe
                refresh_all_ui()
        # No action needed if unchecking (shouldn't be possible if disabled when complete)

    def handle_claim_reward(e: ft.ControlEvent):
        reward_id = e.control.data  # Get reward ID from button data
        if reward_id:
            success = data_manager.claim_reward(app_data, reward_id)
            if success:
                refresh_all_ui()
                # page.update() # Called by refresh_all_ui
            else:
                # Check why it failed (already claimed or not enough points)
                reward_index = data_manager.find_reward_index(app_data, reward_id)
                if reward_index != -1:
                    reward = app_data["rewards"][reward_index]
                    if not reward.get("claimed"):  # Must be due to points
                        show_info_dialog("Not enough points to claim this reward.")
                # No message needed if already claimed, as button should be disabled

    # --- Deletion Handling with Confirmation ---
    item_to_delete = {"type": None, "id": None}  # Store item info for dialog callback

    def handle_delete_item(e: ft.ControlEvent):
        nonlocal item_to_delete
        item_type, item_id = (
            e.control.data
        )  # ("task", "some-uuid") or ("reward", "other-uuid")
        item_to_delete["type"] = item_type
        item_to_delete["id"] = item_id

        # Find the item name for the confirmation message
        item_name = ""
        if item_type == "task":
            idx = data_manager.find_task_index(app_data, item_id)
            if idx != -1:
                item_name = app_data["tasks"][idx].get("name", "")
        elif item_type == "reward":
            idx = data_manager.find_reward_index(app_data, item_id)
            if idx != -1:
                item_name = app_data["rewards"][idx].get("name", "")

        confirm_delete_dialog.content = ft.Text(
            f"Are you sure you want to delete '{item_name}'?"
        )
        page.dialog = confirm_delete_dialog  # Set the active dialog
        confirm_delete_dialog.open = True
        page.update()

    def close_dialog(result=None):
        nonlocal item_to_delete, app_data, pending_import_data
        # Close all potential dialogs
        confirm_delete_dialog.open = False
        info_dialog.open = False
        confirm_import_dialog.open = False

        # Handle delete confirmation
        if result == "yes" and item_to_delete["id"]:
            deleted = False
            if item_to_delete["type"] == "task":
                deleted = data_manager.delete_task(app_data, item_to_delete["id"])
            elif item_to_delete["type"] == "reward":
                deleted = data_manager.delete_reward(app_data, item_to_delete["id"])

            if deleted:
                refresh_all_ui()  # Update UI after deletion
            else:
                # This might happen if the item was deleted between clicking and confirming
                print(
                    f"Failed to delete {item_to_delete['type']} with ID {item_to_delete['id']} (maybe already deleted?)"
                )
                refresh_all_ui()  # Refresh anyway to ensure consistency

        # Handle import confirmation
        elif result == "import_yes" and pending_import_data["data"]:
            print("Import confirmed by user. Overwriting data.")
            app_data = pending_import_data["data"]
            # IMPORTANT: Save the newly imported data to the default location
            data_manager.save_data(app_data)
            refresh_all_ui()  # Update UI with imported data
            show_info_dialog("Data imported successfully!")
        elif result == "import_no":
            print("Import cancelled by user.")

        # Reset temporary states
        item_to_delete = {"type": None, "id": None}
        pending_import_data = {"data": None, "path": None}

        # Reset page.dialog to None or a default if needed,
        # otherwise the last closed dialog stays assigned
        page.dialog = None
        page.update()  # Update page to close the dialog visually

    def show_info_dialog(message):
        info_dialog.content = ft.Text(message)
        page.dialog = info_dialog  # Set the active dialog
        info_dialog.open = True
        page.update()

    # --- Export/Import Button Handlers ---
    def trigger_export(e):
        export_picker.save_file(
            dialog_title="Export Data As...",
            file_name=f"task_reward_data_{datetime.now().strftime('%Y%m%d')}.json",
            allowed_extensions=["json"],
            # initial_directory= # Consider setting an initial directory if possible/needed
        )

    def trigger_import(e):
        import_picker.pick_files(
            dialog_title="Import Data File",
            allow_multiple=False,
            allowed_extensions=["json"],
            # initial_directory= # Consider setting an initial directory
        )

    # --- Build the UI Layout ---
    # Define the main content column first
    main_column = ft.Column(
        [
            points_display,
            ft.Divider(height=10, color=ft.Colors.BLACK26),
            # --- Tasks Section ---
            ft.Text("Add Task", size=16, weight=ft.FontWeight.BOLD),
            ft.Row(
                [task_name_input, task_points_input, task_due_date_input],
                alignment=ft.MainAxisAlignment.SPACE_BETWEEN,  # Space out inputs
            ),
            ft.Container(  # Add padding around button
                content=ft.ElevatedButton(
                    "Add Task",
                    icon=ft.Icons.ADD,
                    on_click=handle_add_task,
                    width=page.width,
                ),  # Make button wider
                padding=ft.padding.symmetric(vertical=5),
            ),
            ft.Text("Pending Tasks", size=16, weight=ft.FontWeight.BOLD),
            ft.Container(
                content=pending_tasks_list,
                # height=200, # Let ListView manage its height within the scrollable column
                border=ft.border.all(1, ft.Colors.BLACK26),
                border_radius=5,
                padding=5,
            ),
            ft.Text("Completed Tasks", size=16, weight=ft.FontWeight.BOLD),
            ft.Container(
                content=completed_tasks_list,
                # height=150,
                border=ft.border.all(1, ft.Colors.BLACK26),
                border_radius=5,
                padding=5,
            ),
            ft.Divider(height=10, color=ft.Colors.BLACK26),
            # --- Rewards Section ---
            ft.Text("Add Reward", size=16, weight=ft.FontWeight.BOLD),
            ft.Row(
                [reward_name_input, reward_cost_input],
                alignment=ft.MainAxisAlignment.SPACE_BETWEEN,
            ),
            ft.Container(
                content=ft.ElevatedButton(
                    "Add Reward",
                    icon=ft.Icons.ADD_SHOPPING_CART,
                    on_click=handle_add_reward,
                    width=page.width,
                ),
                padding=ft.padding.symmetric(vertical=5),
            ),
            ft.Text("Available Rewards", size=16, weight=ft.FontWeight.BOLD),
            ft.Container(
                content=available_rewards_list,
                # height=150,
                border=ft.border.all(1, ft.Colors.BLACK26),
                border_radius=5,
                padding=5,
            ),
            ft.Text("Claimed Rewards", size=16, weight=ft.FontWeight.BOLD),
            ft.Container(
                content=claimed_rewards_list,
                # height=100,
                border=ft.border.all(1, ft.Colors.BLACK26),
                border_radius=5,
                padding=5,
            ),
            ft.Divider(height=10, color=ft.Colors.BLACK26),
            # --- Views ---
            # Consider using Tabs for these sections if the page gets too long
            ft.Text("Calendar (Tasks by Due Date)", size=16, weight=ft.FontWeight.BOLD),
            ft.Container(
                content=calendar_list,
                # height=200,
                border=ft.border.all(1, ft.Colors.BLACK26),
                border_radius=5,
                padding=5,
            ),
            ft.Text("History", size=16, weight=ft.FontWeight.BOLD),
            ft.Container(
                content=history_list,
                # height=200,
                border=ft.border.all(1, ft.Colors.BLACK26),
                border_radius=5,
                padding=5,
            ),
            ft.Divider(height=10, color=ft.Colors.BLACK26),
            # --- Data Management ---
            ft.Text("Manage Data", size=16, weight=ft.FontWeight.BOLD),
            ft.Row(
                [
                    ft.ElevatedButton(
                        "Export Data",
                        icon=ft.Icons.UPLOAD_FILE,
                        on_click=trigger_export,
                        expand=True,
                    ),
                    ft.ElevatedButton(
                        "Import Data",
                        icon=ft.Icons.DOWNLOAD,
                        on_click=trigger_import,
                        expand=True,
                    ),
                ],
                alignment=ft.MainAxisAlignment.SPACE_EVENLY,
            ),
            ft.Text(
                "Warning: Importing data will overwrite current local data.",
                size=10,
                italic=True,
                color=ft.Colors.ERROR,
                text_align=ft.TextAlign.CENTER,
            ),
        ],
        scroll=ft.ScrollMode.ADAPTIVE,  # Make the main column scrollable if content overflows
        expand=True,  # Allow column to take available vertical space
        spacing=10,  # Add some space between major sections
    )

    # Add the main column wrapped in SafeArea directly to the page
    page.add(ft.SafeArea(main_column, expand=True))  # Ensure SafeArea also expands

    # --- Initial UI Population ---
    refresh_all_ui()
    # page.update() # Called by refresh_all_ui


# --- Run the App ---
if __name__ == "__main__":
    ft.app(target=main)
